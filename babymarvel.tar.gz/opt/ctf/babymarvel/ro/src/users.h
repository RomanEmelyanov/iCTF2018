
int user_exists(char* username);

int load_password(char* username, char* password);

void set_password(char* username, char* password);

